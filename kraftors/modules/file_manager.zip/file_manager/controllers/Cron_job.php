<?php


// defined('BASEPATH') or exit('No direct script access allowed');

class Cron_job extends AdminController
{
	public function __construct()
    {
        parent::__construct();
        $this->load->model('file_model');
        $se = send_mail_template('staff_reminder', 'amit.verma@nbgspl.com','1', 'fdsfdsgfgdu');
       if($se){
           echo'success';
       }else{
           echo'failed';
       }
      
    }

	public function index()
	{
	 echo "helloqqqqqqqqqq 123445465";
	   $se = send_mail_template('staff_reminder', 'amit.verma@nbgspl.com','1', 'fdsfdsgfgdu');
       if($se){
           echo'success';
       }else{
           echo'failed';
       }
	 
	}

}