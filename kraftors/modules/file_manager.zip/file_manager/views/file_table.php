<?php

defined('BASEPATH') or exit('No direct script access allowed');

$base_currency = get_base_currency();

$aColumns = [
    'position_id',
    'position_code',
    'position_name',
    'job_position_description',
    'department_id',
    //'job_p_id',
    
    ];

$sIndexColumn = 'position_id';
$sTable       = db_prefix() . 'hr_job_position';

$join = [];

$where  = [];
$filter = [];
//$this->ci->load->model('hr_profile_model');
//load deparment by manager
if(!is_admin() && !has_permission('staffmanage_job_position','','view')){
 
      //View own
  $array_department = $this->ci->hr_profile_model->get_department_by_manager();
  if (count($array_department) > 0) {
    $department_m_where = '';
    foreach ($array_department as $department_id_m) {
      if ($department_id_m != '') {

        if ($department_m_where == '') {
          $department_m_where .= ' AND (find_in_set('.$department_id_m.', '.db_prefix().'hr_job_position.department_id) ';

        } else {
          $department_m_where .= ' OR find_in_set('.$department_id_m.', '.db_prefix().'hr_job_position.department_id) ';
        }

      }
    }

    if ($department_m_where != '') {
      $department_m_where .= ')';

      $where[] = $department_m_where;
    }

  }else{
    $where[] = 'AND 1=2';
  }
}

$department_ids = $this->ci->input->post('department_id');
$job_p_ids = $this->ci->input->post('job_p_id');

if(isset($department_ids)){

    $department_where = '';
    foreach ($department_ids as $department_id) {
        if ($department_id != '') {

            if ($department_where == '') {
                $department_where .= ' AND (find_in_set('.$department_id.', '.db_prefix().'hr_job_position.department_id) ';

            } else {
                $department_where .= ' OR find_in_set('.$department_id.', '.db_prefix().'hr_job_position.department_id) ';
            }

        }
    }

    if ($department_where != '') {
        $department_where .= ')';

        $where[] = $department_where;
    }

}

if(isset($job_p_ids)){
    $job_p_where = '';
    foreach ($job_p_ids as $job_p_id) {
        if ($job_p_id != '') {

            if ($job_p_where == '') {
                $job_p_where .= ' AND (( '.db_prefix().'hr_job_position.job_p_id) = '.$job_p_id;

            } else {
                $job_p_where .= ' OR ('.db_prefix().'hr_job_position.job_p_id = '.$job_p_id.') ';
            }

        }
    }

    if ($job_p_where != '') {
        $job_p_where .= ')';

        $where[] = $job_p_where;
    }


}



$result = data_tables_init($aColumns, $sIndexColumn, $sTable, $join, $where, ['position_id', 'department_id']);

$output  = $result['output'];
$rResult = $result['rResult'];


if(is_admin(get_staff_user_id())){
    $file = $this->ci->file_model->get_filedata();
}

//$file = $this->ci->file_model->get_filedata();
// echo'<pre>';
// print_r($file);
// exit;


$rResult = $file;
foreach ($rResult as $aRow) {
    $row = [];

    $row[] = '<div class="checkbox"><input type="checkbox" value="' . $aRow['id'] . '"><label></label></div>';
    //$row[] = $aRow['id'];
    
     $auditsflow = $this->ci->db->select('*')->where('file',$aRow['id'])->get('tblfile_auditflow')->result_array();
     $flow = '';
     $flow .= '<div class="popDawn"><ul>';
     	foreach($auditsflow as $key =>$value){
 		  $staffname = $this->ci->db->select('firstname,lastname')->where('staffid',$value['staff'])->get('tblstaff')->result_array();
 		    foreach($staffname as $staffkey=>$staffvalue){
 		        $flow .='<li>'.$staffvalue['firstname'].' '.$staffvalue['lastname'].'</li>';
 		    }
  		}
    $flow .='</ul></div>';
 	
     $subjectOutput ='';

    //  if (has_permission('staffmanage_job_position', '', 'view') || has_permission('staffmanage_job_position', '', 'view_own' ) || is_admin()){ 

          $subjectOutput .= '<a class="nameT" href="javacript:void(0);">'. $aRow['filename'].' '.$flow.'</a>';
    //  }


     $subjectOutput .= '<div class="row-options">';

    // if (has_permission('staffmanage_job_position', '', 'view') || has_permission('staffmanage_job_position', '', 'view_own' ) || is_admin()){
          //$subjectOutput .= '<a href="'.admin_url('file_manager/file_view_edit/'.$aRow['id']).'">'. _l('hr_view').'</a>';
          $subjectOutput .=' <a href="'.admin_url('file_manager/view_file/'.$aRow['id']).'" data-document_file="'. $aRow['file'].'"  data-toggle="sidebar-right" >'._l('View').'</a>';
    // }

    // if (has_permission('staffmanage_job_position', '', 'edit') || is_admin()){
          $subjectOutput .=' <a href="#" onclick="edit_file(this,'.$aRow['id'].'); return false" data-name="'. $aRow['filename'].'" data-category_id="'. $aRow['category_id'].'" data-subcategory_id="'. $aRow['subcategory_id'].'" data-review_date="'. $aRow['review_date'].'" data-file_description="'. $aRow['file_description'].'" data-document_file="'. $aRow['file'].'" data-groupid="'. $aRow['groupid'].'"  data-toggle="sidebar-right" >'._l('hr_edit').'</a>';
    // }

    // if (has_permission('staffmanage_job_position', '', 'delete') || is_admin()){
         //$subjectOutput .=' | <a href="'.admin_url('file_manager/delete_jfile/'.$aRow['id']).'" class="text-danger _delete" >'. _l('delete').'</a>';
         $subjectOutput .=' | <a href="'.admin_url('file_manager/delete_file/'.$aRow['id']).'" class="text-danger _delete" >'. _l('delete').'</a>';
    // }

    $subjectOutput .= '</div>';
    $row[] = $subjectOutput;

    //$row[] = $aRow['filename'];

    if($aRow['category_id']){
        $cat_name = $this->ci->file_model->get_categoryname_by_id($aRow['category_id']);
    }else{
        $cat_name = '';
    }
    
    $row[] = $cat_name;

    if($aRow['category_id']){
        $subcat_name = $this->ci->file_model->get_subcategoryname_by_id($aRow['subcategory_id']);
    }else{
        $subcat_name = '';
    }
    
    $row[] = $subcat_name;

    /*get frist 100 character */
    //  if(strlen($aRow['job_position_description']) > 200){
    //     $pos=strpos($aRow['job_position_description'], ' ', 200);
    //     $description_sub = substr($aRow['job_position_description'],0,$pos ); 
    //   }else{
    //     $description_sub = $aRow['job_position_description'];
    //   }

    $description_sub =  $aRow['file_description'];
    $row[] = $description_sub;

    $row[] = $aRow['review_date'];

	// get department
    // if($aRow['department_id'] != null && $aRow['department_id'] != ''){
    //           $members       = explode(',', $aRow['department_id']);
    //           $str = '';
    //           $j = 0;
    //           foreach ($members as $key => $member_id) {
    //             $member   = $this->ci->hr_profile_model->hr_profile_get_department_name($member_id);

    //             $j++;
    //             $str .= '<span class="label label-tag tag-id-1"><span class="tag">'.$member->name.'</span><span class="hide">, </span></span>&nbsp';

    //             if($j%2 == 0){
    //              $str .= '<br><br/>';
    //            }

    //          }
    //          $_data = $str;
    //        }
    //        else{
    //         $_data = '';
    //       }

    //$row[] = $_data;

    //get parent name
    // $job_p = $this->ci->hr_profile_model->get_job_p($aRow['job_p_id']) ; 
    // $row[] = isset($job_p) ? $job_p->job_name :'';

    $output['aaData'][] = $row;
}

?>
