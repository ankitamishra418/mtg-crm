<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
	<div class="content">
		<div class="row">

			<?php if($this->session->flashdata('debug')){ ?>
				<div class="col-lg-12">
					<div class="alert alert-warning">
						<?php echo html_entity_decode($this->session->flashdata('debug')); ?>
					</div>
				</div>
			<?php } ?>
            <?php $file = $file[0]; ?>
			<div class="col-md-12">
				<div class="panel_s">
					<div class="panel-body">
						<div role="tabpanel" class="tab-pane" id="job_position_tab">
                        <div class="row">
                            <div class="col-md-4 col-xs-12">
                                <img class="fileImags" src="https://www.thoughtco.com/thmb/l02eHirN3GViukVErJSqJCRAEuM=/768x0/filters:no_upscale():max_bytes(150000):strip_icc()/GettyImages-116248249-5be59c3cc9e77c00514fed87.jpg" alt="Girl in a jacket">
						        <a class="downloadIcon" download='file' src="https://www.thoughtco.com/thmb/l02eHirN3GViukVErJSqJCRAEuM=/768x0/filters:no_upscale():max_bytes(150000):strip_icc()/GettyImages-116248249-5be59c3cc9e77c00514fed87.jpg" target="_blank" href="https://www.thoughtco.com/thmb/l02eHirN3GViukVErJSqJCRAEuM=/768x0/filters:no_upscale():max_bytes(150000):strip_icc()/GettyImages-116248249-5be59c3cc9e77c00514fed87.jpg" title='full view'><i class="fa fa-download"></i></a>
						    </div>
                            <div class="col-md-8 col-xs-12">
                                <h3><?php echo $file['filename']?></h3>
                                <sapn> Category : <?php echo  $this->file_model->get_categoryname_by_id($file['category_id']); ?></sapn><br>
                                <sapn> Sub Category : <?php echo  $this->file_model->get_subcategoryname_by_id($file['subcategory_id']); ?></sapn><br>
                                <sapn> Description : <?php echo $file['file_description']?></sapn><br>
                                <?php $staffname = $this->db->select('firstname,lastname')->where('staffid',$file['addfrom'])->get('tblstaff')->result_array(); 
                                foreach($staffname as $staffkey=>$staffvalue){
                         		        $staff_nmae ='<span>'.$staffvalue['firstname'].' '.$staffvalue['lastname'].'</span>';
                         		    }
                                ?>
                                <sapn> Uploaded by : <?php echo $staff_nmae?></sapn><br>
                                <div class="clearfix"></div>
        						<br>
                            </div>
                        </div>
						
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>

		<div class="btn-bottom-pusher"></div>
		<div id="contract_file_data"></div>
		<div id="new_version"></div>
	</div>
  </div>
</div>

<?php init_tail(); ?>

</body>
</html>